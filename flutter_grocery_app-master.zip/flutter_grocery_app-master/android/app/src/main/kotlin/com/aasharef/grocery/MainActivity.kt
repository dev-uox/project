package com.aasharef.grocery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
