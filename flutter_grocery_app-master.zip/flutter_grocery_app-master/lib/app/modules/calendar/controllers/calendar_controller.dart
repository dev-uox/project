import 'package:get/get.dart';

class CalendarController extends GetxController {}
